package com.msun.MsunEngineer.Actions.EditorPopupMenu;

import org.cef.browser.CefBrowser;

public class EditorForContext {
    public enum editorType {DEFAULT,SELECTION,FILE};
    public void AddActiveEditorAsContext(CefBrowser browser){

    }
}
